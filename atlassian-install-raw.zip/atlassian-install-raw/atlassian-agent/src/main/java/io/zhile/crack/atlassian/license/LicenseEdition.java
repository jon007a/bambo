package io.zhile.crack.atlassian.license;

/**
 * @author pengzhile
 * @link https://zhile.io
 * @version 1.0
 */
public enum LicenseEdition {
    BASIC,
    STANDARD,
    PROFESSIONAL,
    ENTERPRISE,
    UNLIMITED,
}
